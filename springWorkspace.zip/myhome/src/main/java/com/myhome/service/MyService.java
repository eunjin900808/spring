package com.myhome.service;

import com.myhome.dto.MyboardDto;

public interface MyService {

	/**
	 * 입력처리
	 * @param dto
	 * @return integer
	 * @throws Exception
	 */
	int insertMyboard(MyboardDto dto) throws Exception;
}
