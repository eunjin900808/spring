package com.myhome.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.myhome.dto.MyboardDto;
import com.myhome.mapper.MyMapper;

@Service
public class MyServiceImpl implements MyService{

	@Autowired
	MyMapper mapper;
	
	@Override
	public int insertMyboard(MyboardDto dto) throws Exception {
		
		return mapper.insertMyboard(dto);
	}

}
