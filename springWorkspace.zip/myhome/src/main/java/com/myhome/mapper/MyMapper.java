package com.myhome.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.myhome.dto.MyboardDto;

@Mapper
public interface MyMapper {

	int insertMyboard(MyboardDto dto);

}
