package com.myhome.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.myhome.dto.DefaultDto;
import com.myhome.dto.MyboardDto;
import com.myhome.service.MyService;


@Controller
public class MyController {

	@Autowired
	MyService myService;
	
	@GetMapping("myboardWrite")
	public String myboardWrite() {
		return "board/myboardWrite";
	}
	
	@PostMapping("myboardInsert")
	@ResponseBody
	public String insertMyboard(MyboardDto dto) throws Exception{
		
		System.out.println("제목:"+dto.getTitle());
		
		String message = "ok";
		// 저장(등록) 서비스 실행
		int result = myService.insertMyboard(dto);
		
		if(result == 0) message = "fail";
		
		
		return message;
	}
	
	@GetMapping("myboardList")
	public String selectMyboardList(DefaultDto dto) throws Exception{
		
		//서비스 실행
//		List<?> list =myService.selectMyboardList(dto);
		return "board/myboardList";
	}
}
